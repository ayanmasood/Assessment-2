new Vue({
  el:"#app",
  data:{
    todos:[
      {text:"Assignment 1", done:true},
      {text:"Assignment 2", done:false},
      {text:"Assignment 3", done:false}
    ]
  },
  methods:{
    toggle:function(todo){
      todo.done=!todo.done
    }
  }
})